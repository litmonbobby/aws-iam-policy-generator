import argparse
import json

TEMPLATES = {
    "s3": {
        "read-only": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "s3:GetObject",
                        "s3:ListBucket"
                    ],
                    "Resource": "*"
                }
            ]
        }
    },
    "ec2": {
        "start-stop": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "ec2:StartInstances",
                        "ec2:StopInstances"
                    ],
                    "Resource": "*"
                }
            ]
        }
    },
    "lambda": {
        "invoke-only": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "lambda:InvokeFunction"
                    ],
                    "Resource": "*"
                }
            ]
        }
    }
}

def generate_policy(service, access):
    try:
        policy = TEMPLATES[service][access]
        print(json.dumps(policy, indent=2))
    except KeyError:
        print("Error: Invalid service or access type. Use --help for valid options.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate AWS IAM Policy JSON")
    parser.add_argument("--service", required=True, help="Service name (s3, ec2, lambda)")
    parser.add_argument("--access", required=True, help="Access type (read-only, start-stop, invoke-only)")
    args = parser.parse_args()

    generate_policy(args.service, args.access)
